fun main()
{
    var i:Int = 10
    println("Integer Value: $i")
    var f:Float = 1.3F
    println("Float Value: $f")
    var c:Char = 'H'
    println("Character Value: $c")
    var s:String = "Jainam"
    println("String Value: $s")
    var b:Boolean = false
    println("Boolean Value: $b")
    var d:Double = 10.1
    println("Double Value: $d")
    var l:Long = 123456789
    println("Long Value: $l")
    var sh:Short = -54
    println("Short Value: $sh")
    var by:Byte = 123
    println("Byte Value: $by")
}