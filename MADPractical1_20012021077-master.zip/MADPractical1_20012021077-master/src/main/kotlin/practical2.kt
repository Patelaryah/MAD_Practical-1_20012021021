fun main(){
    var i:Int = 12
    println("Integer value: $i")
    var d:Double = i.toDouble()
    println("Double Value (From Integer):$d")
    var s:String = "10"
    println("String Value: $s")
    var i1:Int = s.toInt()
    println("Integer Value1 (From String):$i1")
    var d1:Double = s.toDouble()
    println("Double Value (From String):$d1")
}