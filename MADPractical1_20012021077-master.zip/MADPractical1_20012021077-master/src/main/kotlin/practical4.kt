fun main() {
    println("Enter the number")
    var num = readLine()!!.toInt()
    if (num % 2 == 0) {
        print("$num is even")
    } else {
        print("$num is odd")
    }
}